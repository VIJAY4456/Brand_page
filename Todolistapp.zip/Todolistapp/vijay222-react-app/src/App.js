import React from "react";
import Todo from "./component/todoreact/todo";


const App = () => {
  return <Todo/>;
  
};

export default App







